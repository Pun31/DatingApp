﻿using DatingApp.Server.Configurations.Entities;
using DatingApp.Server.Models;
using DatingApp.Shared.Domain;
using IdentityServer4.EntityFramework.Options;
using Microsoft.AspNetCore.ApiAuthorization.IdentityServer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DatingApp.Server.Data
{
    public class ApplicationDbContext : ApiAuthorizationDbContext<ApplicationUser>
    {
        public ApplicationDbContext(
            DbContextOptions options,
            IOptions<OperationalStoreOptions> operationalStoreOptions) : base(options, operationalStoreOptions)
        {
        }
        public DbSet<Player> Players { get; set; }
        public DbSet<Message> Messages { get; set; }
        public DbSet<Consultation> Consultations { get; set; }
        public DbSet<MatchType> MatchTypes { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.ApplyConfiguration(new PlayerSeedConfiguration());
            builder.ApplyConfiguration(new MessageSeedConfiguration());
            builder.ApplyConfiguration(new ConsultationSeedConfiguration());
            builder.ApplyConfiguration(new MatchTypeSeedConfiguration());

        }
    }
}
